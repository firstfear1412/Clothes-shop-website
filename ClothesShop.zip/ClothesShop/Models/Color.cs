﻿using System;
using System.Collections.Generic;

namespace ClothesShop.Models;

public partial class Color
{
    public byte ColorId { get; set; }

    public string ColorName { get; set; } = null!;
}

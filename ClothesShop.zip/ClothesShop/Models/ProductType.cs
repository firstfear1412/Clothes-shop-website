﻿using System;
using System.Collections.Generic;

namespace ClothesShop.Models;

public partial class ProductType
{
    public byte PdtId { get; set; }

    public string? PdtName { get; set; }
}

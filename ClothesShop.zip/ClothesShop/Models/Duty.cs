﻿using System;
using System.Collections.Generic;

namespace ClothesShop.Models;

public partial class Duty
{
    public string DutyId { get; set; } = null!;

    public string? DutyName { get; set; }
}

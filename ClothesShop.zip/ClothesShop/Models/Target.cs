﻿using System;
using System.Collections.Generic;

namespace ClothesShop.Models;

public partial class Target
{
    public byte TargetId { get; set; }

    public string? TargetName { get; set; }
}

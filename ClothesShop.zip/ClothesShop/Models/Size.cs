﻿using System;
using System.Collections.Generic;

namespace ClothesShop.Models;

public partial class Size
{
    public byte SizeId { get; set; }

    public string? SizeName { get; set; }
}
